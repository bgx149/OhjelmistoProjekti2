class VinyyliSovellus {
	
    constructor(listaus, riviTemplate, lomake) {
        this.vinyylilistaus = listaus;
        this.vinyyliriviTemplate = riviTemplate;
        this.vinyylit = [];
        this.alustaUusiVinyyliLomake(lomake);
    }

    async lataaVinyylit() {
        try {
            let response = await fetch("/api/vinyylit");
            this.vinyylit = await response.json();
            this.renderoiVinyylit();
        } catch (error) {
            console.error(error);
            alert('Tapahtui virhe. Tutki selaimen consolea ja palvelimen consolea!');
        }
    }

    renderoiVinyylit() {
        this.vinyylilistaus.innerHTML = ''; // tyhjennetään listaus
        for (let vinyyli of this.vinyylit) {
            let vinyyliNode = this.renderoiVinyyli(vinyyli);
            this.vinyylilistaus.appendChild(vinyyliNode);
        }
      
       
        
        
    }

    renderoiVinyyli(vinyyli) {
        // Tehdään kopio asiaskarivitemplatesta (true -> deep copy)
        let uusiVinyyliNode = document.importNode(this.vinyyliriviTemplate.content, true);
        uusiVinyyliNode.querySelector('.artisti').innerText = vinyyli.artisti;
        uusiVinyyliNode.querySelector('.nimi').innerText = vinyyli.nimi;
        uusiVinyyliNode.querySelector('.vuosi').innerText = vinyyli.vuosi;
        uusiVinyyliNode.querySelector('.hinta').innerText = vinyyli.hinta;

        return uusiVinyyliNode;
    }
    
    async lisaaUusiVinyyli(vinyyli) {
        try {
            let response = await fetch("/api/vinyylit", {
                method: 'POST',
                body: JSON.stringify(asiakas),
                headers: {
                    'Content-type': 'application/json; charset=UTF-8'
                }
            });
           
            this.lataaVinyylit();   
            // vaihtoehto B, jos lisäyksen yhteydessä uuden asiakkaan id-arvo palautuisi fetch-kutsussa
            // let json = await response.json();
            // this.asiakkaat.push(json);
            // this.renderoiAsiakkaat();
            return true;
        } catch (error) {
            console.error(error);
            alert('Tapahtui virhe. Tutki selaimen consolea ja palvelimen consolea!');
            return false;
        }
    }

    

    alustaUusiVinyyliLomake(lomake) {
        lomake.onsubmit = () => {
            let artisti = lomake.querySelector('#uusi-vinyyli-artisti');
            let nimi = lomake.querySelector('#uusi-vinyyli-nimi');
            let vuosi = lomake.querySelector('#uusi-vinyyli-vuosi');
            let hinta = lomake.querySelector('#uusi-vinyyli-hinta');
            
            let vinyyli = {
                artisti : artisti.value,
                nimi : nimi.value,
                vuosi : vuosi.value,
                hinta : hinta.value,
            };
            this.lisaaUusiVinyyli(vinyyli);

            artisti.value = ''; // tyhjennä syöttökentät tallennuksen jälkeen
            nimi.value = '';
            vuosi.value = '';
            hinta.value = '';
            
            return false; // estää sivun uudelleenlatauksen
        }
        
       
    }
    async poistaVinyyli(poistettavaVinyyli) {
        try {
            let response = await fetch("/api/vinyylit"+ '?vinyyliid=${poistettavaVinyyli.vinyylitunnus}',
            		{ method: 'DELETE' }
            );
            this.vinyylit = this.vinyylit.filter(vinyyli => vinyyli !== poistettavaVinyyli);
            this.renderoiVinyylit();
        } catch (error) {
            console.error(error);
            alert('Tapahtui virhe. Tutki selaimen consolea ja palvelimen consolea!');
        }
    }
    
    
    }
    
    

    