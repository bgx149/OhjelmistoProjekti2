



		async function lataaVinyylit() {
 try {
       let response = await fetch("/api/vinyylit", {
                method: 'GET'});
       let vinyylit = await response.json();
       
       let vinyylilistaus =  document.querySelector("#vinyylilistaus"); //document.getElementById("vinyylilistaus");
       let vinyyliriviTemplate = document.querySelector("#vinyylirivi-template");
        
       for (let vinyyli of vinyylitt) {
            //console.log (vinyyli.nimi);
            
            let uusiVinyyliNode = document.importNode(vinyyliriviTemplate.content, true);
        	uusiVinyyliNode.querySelector('.artisti').innerText = asiakas.artisti;
        	uusiVinyyliNode.querySelector('.nimi').innerText = asiakas.nimi;
            vinyylilistaus.appendChild(uusiVinyyliNode);
        }
      } catch (error) {
            console.error(error);
            alert('Tapahtui virhe. Tutki selaimen consolea ja palvelimen consolea!');
      }
 }

lataaVinyylit();
    
    

    
