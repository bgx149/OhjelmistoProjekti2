package control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.Database;
import database.VinyyliDAO;
import database.VinyyliJdbcDao;
import model.Vinyyli;

/**
 * Servlet implementation class EtsiServlet
 */
@WebServlet("/etsi-vinyyli")
public class EtsiVinyyliServlet extends HttpServlet {
	/**
	 * Vastaanottaa selaimelta tulleen pizzan poistopyynnön
	 * 
	 * @param request
	 *            pyyntö
	 * @param response
	 *            vastaus
	 */

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		
		}
}

