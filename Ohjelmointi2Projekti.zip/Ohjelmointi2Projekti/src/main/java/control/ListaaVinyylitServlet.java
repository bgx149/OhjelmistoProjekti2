package control;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.VinyyliDAO;
import database.VinyyliJdbcDao;
import model.Vinyyli;

@WebServlet("/listaa-vinyylit") // käsitt.pyynnön http://localhost:8080/listaa-vinyylit
 
public class ListaaVinyylitServlet extends HttpServlet {
	 
		protected void doGet(HttpServletRequest request,
			 	HttpServletResponse response) throws ServletException, IOException {
			
			// haetaan pizzat tietokannasta
			VinyyliDAO vinyylidao = new VinyyliJdbcDao();
			List<Vinyyli> vinyylit = vinyylidao.FindAll();
			
			// pizzat-lista .jsp:n saataville
			request.setAttribute("vinyylit", vinyylit); 
			
			request.getRequestDispatcher("/WEB-INF/vinyylilist1.jsp").forward(request, response);
			
			
}
}