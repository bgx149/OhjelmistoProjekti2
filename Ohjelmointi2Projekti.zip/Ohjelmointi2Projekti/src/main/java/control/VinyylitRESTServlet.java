package control;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import database.VinyyliDAO;
import database.VinyyliJdbcDao;
import model.Vinyyli;

@WebServlet("/api/vinyylit") // http://localhost:8080/api/vinyylit

/*
 * REST-metodeita Asiakkaat-tietoresurssiin liittyen. Endpoint + HttpMethod +
 * (Action) konvention mukaisia: 
 * /api/asiakkaat + GET (kaikki asiakkaat)
 * /api/asiakkaat/{id} + GET (yksi asiakas id-arvon perusteella) 
 * /api/asiakkaat + POST (lisää uusi asiakas) 
 * /api/asiakkaat + DELETE (poista asiakas) 
 * /api/asiakkaat + PUT (muokkaa asiakas)
 */
public class VinyylitRESTServlet extends HttpServlet {

	/**
	 * REST-metodi, endpoint: /api/asiakkaat, method: GET, action: hae kaikki asiakkaat
	 * 
	 * Lähettää selaimelle tietokannasta haetut kaikki asiakkaat JSON-muodossa
	 */
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			
			VinyyliDAO vinyylidao = new VinyyliJdbcDao();
			List<Vinyyli> vinyylit = vinyylidao.FindAll();
			
			String strJson = new Gson().toJson(vinyylit);
			System.out.println(strJson);
			response.setContentType("application/json; charset=UTF-8");
			response.getWriter().println(strJson);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Selaimelta tulleen JSON-muotoisen asiakastiedon deserialisointi
		// Java-kieliseksi
		// Asiakas-luokan olioksi
		try {

			// Saadaan JSON-tiedot request-oliolta
			// Luetaan POST-pyynnön body-osuudesta kaikkien rivien sisältö yhdeksi
			// String-olioksi
			String strJSONInput = request.getReader().lines().collect(Collectors.joining());
			System.out.println(strJSONInput);

			// Luodaan uusi Asiakas-luokan olio JSON-datan perusteella
			Vinyyli vinyyli = new Gson().fromJson(strJSONInput, Vinyyli.class);
			System.out.println(vinyyli);

			// Luodaan asiakasdao
			VinyyliDAO vinyylidao = new VinyyliJdbcDao();
			// Lisätään asiakkaan tiedot tietokantaan
			vinyylidao.addVinyyli(vinyyli);

			String strJSONOutput = new Gson().toJson(vinyyli);
			response.setContentType("application/json; charset=UTF-8");
			// selaimeen lähetetään tietokantaan lisätty asiakas JSON-muodossa
			response.getWriter().println(strJSONOutput); // ei vielä palauta asiakkaan id-arvoa

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * REST-metodi, endpoint: /api/asiakkaat, method: DELETE, action: poistaa asiakkaan
	 * id-arvon perusteella 
	 * Poistaa tietokannasta parametrina tulleen asiakas-id:n
	 * perusteella yhden asiakkaan
	 */
	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			// Haetaan request-oliolta parametreista poistettavan asiakkaan id-arvo
			String idStr = request.getParameter("vinyyliid");
			System.out.println("Poistettavan vinyylin id: " + idStr);
			int vinyyliId = Integer.parseInt(idStr);
			// Luodaan asiakasdao
			VinyyliDAO vinyylidao = new VinyyliJdbcDao();
			// Poistetaan asiakkaan tiedot tietokannasta
			vinyylidao.removeVinyyli(vinyyliId);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

	