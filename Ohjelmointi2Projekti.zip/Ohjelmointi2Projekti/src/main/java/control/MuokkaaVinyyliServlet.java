package control;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.VinyyliDAO;
import database.VinyyliJdbcDao;
import model.Vinyyli;

@WebServlet("/muokkaa-vinyyli") // käsitt.pyynnön http://localhost:8080/listaa-vinyylit
 
public class MuokkaaVinyyliServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		try {
			// Sijoitetaan muuttujaan pyynnön parametrina tullut poistettavan asiakkaan
			// id-arvo
			String idStr = request.getParameter("vinyyliid");
			int vinyyliId = Integer.parseInt(idStr);
			// Luodaan vinyylidao
			VinyyliDAO vinyylidao = new VinyyliJdbcDao();
			// Poistetaan pizza tiedot tietokannasta
			boolean poistoOnnistui = vinyylidao.MuokkaaVinyyli(vinyyliId);
			if (poistoOnnistui) {
				// uudelleenohjataan pyyntö /listaa-pizza-endpointiin
				response.sendRedirect("/listaa-vinyylit");
			} else {
				request.setAttribute("viesti", "Vinyylin poistossa tapahtui virhe.");
				// servlet kutsuu jsp:tä
				request.getRequestDispatcher("/WEB-INF/tapahtumaraportti.jsp").forward(request, response);
			}
			
		} catch (Exception e) {
			e.printStackTrace();	
			request.setAttribute("viesti", "Sovelluksessa tapahtui virhe,");
			// servlet kutsuu jsp:tä
			request.getRequestDispatcher("/WEB-INF/tapahtumaraportti.jsp").forward(request, response);
		}

		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}



	 