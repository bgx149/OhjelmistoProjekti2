package control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.VinyyliDAO;
import database.VinyyliJdbcDao;
import model.Vinyyli;

@WebServlet("/lisaa-vinyyli") // käsitt.pyynnön http://localhost:8080/lisaa-vinyyli


public class VinyyliHallintaServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			// kutsutaan pizza-lomake.jsp:tä
			request.getRequestDispatcher("/WEB-INF/hallinta.jsp").forward(request, response);
			}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Pyydetään lomakkeella syötetyn pizzan tiedot request-oliolta

		try {

			String artisti = request.getParameter("artisti"); // 
			String nimi = request.getParameter("nimi"); // 
			
			String vuosiStr = request.getParameter("vuosi");
			int vuosi = Integer.parseInt(vuosiStr);

			String hintaStr = request.getParameter("hinta"); // hinta
			double hinta = Double.parseDouble(hintaStr);

			

			// Luodaan uusi Pizza-luokan olio edellisillä parametreillä
			Vinyyli vinyylit = new Vinyyli(0,artisti, nimi, vuosi, hinta);
			VinyyliDAO vinyylidao = new VinyyliJdbcDao();
			
			boolean lisaysOnnistui = vinyylidao.addVinyyli(vinyylit);
			if (lisaysOnnistui){
			 
			 response.sendRedirect("/listaa-vinyylit");
			}else {
			request.setAttribute("viesti", "Vinyylin lisäyksessä tietokantaan tapahtui virhe.");
			// servlet kutsuu jsp:tä
			request.getRequestDispatcher("/WEB-INF/tapahtumaraportti.jsp").forward(request, response);
			}
		} catch (NumberFormatException e) {
			
			e.printStackTrace();  // tulostetaan Consoleen virhetilanteessa metodikutsupinoa, josta näkee rivinumeron, jossa Exception tapahtuu

			request.setAttribute("viesti", "Vinyyli-lomakkeella syötetyt tiedot eivät olleet kelvolliset.");
			// servlet kutsuu jsp:tä
			request.getRequestDispatcher("/WEB-INF/tapahtumaraportti.jsp").forward(request, response);
		}
		
	}
}
	
	

