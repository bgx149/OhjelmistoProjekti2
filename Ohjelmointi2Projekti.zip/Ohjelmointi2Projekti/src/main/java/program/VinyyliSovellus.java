package program;

import java.util.Scanner;
import model.Vinyyli;
import java.util.List;
import database.VinyyliDAO;
import database.VinyyliJdbcDao;


public class VinyyliSovellus {
	
	private static Scanner input = new Scanner(System.in);
	
	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		System.out.println("Vinyylisovellus");
		int valinta = -1;
		while (valinta != 0) {
			System.out.print("\n 1 Listaa vinyyliy \n 2 Lisää vinyyli \n 3 Poista vinyyli \n 0 Lopeta");
			System.out.print("\n Syötä valintasi: ");
			valinta = input.nextInt();
			input.nextLine(); // syöttöpuskurin tyhjennys, rivinvaihtomerkin lukeminen erikseen

			if (valinta == 1) {
				listaaVinyylit();
			} else if (valinta == 2){
				lisaaVinyyli();
			} else if (valinta == 3){
				poistaVinyyli();
			} else if (valinta == 0){
				System.out.println("Kiitos ja näkemiin!");
			} else {
				System.out.println("Virheellinen valinta. Valitse uudelleen!");
			}

		} while (valinta != 0);
		input.close();
	}
	
	private static void listaaVinyylit() {

		VinyyliDAO vinyylidao = new VinyyliJdbcDao();
		List<Vinyyli> vinyylit = vinyylidao.FindAll();
		System.out.println("\nVinyylit: ");
		for (Vinyyli vinyyli : vinyylit) {
			System.out.println(vinyyli);
			}
		}
	
	private static void lisaaVinyyli() { 
		Vinyyli uusiVinyyli = new Vinyyli(0, null, null, 0, 0);
		System.out.println("\nSyötä lisättävän Vinyylin tiedot!");
		System.out.print("Anna artisti:" );
		uusiVinyyli.setArtisti(input.nextLine());
		System.out.print("Anna nimi:" );
		uusiVinyyli.setNimi(input.nextLine());
		System.out.println("Anna vuosi: ");
		uusiVinyyli.setVuosi(input.nextInt());
		System.out.print("Anna hinta: ");
		uusiVinyyli.setHinta(input.nextDouble());
		input.nextLine(); // rivinvaihtomerkin lukeminen pois syöttöpuskurista 
		// numeerisen arvon lukemisen jälkeen

		VinyyliDAO vinyylidao = new VinyyliJdbcDao();
		
		
		boolean onnistuiLisays = vinyylidao.addVinyyli(uusiVinyyli);
		if (onnistuiLisays) {
			System.out.println("Vinyylin tietojen lisäys tietokantaan onnistui.");
		} else {
			System.out.println("Vinyylin tietojen lisäys tietokantaan ei onnistunut.");
		}
	}
	
private static void poistaVinyyli() {

		int vinyyliId = 0;
		System.out.print("\nSyötä poistettavan vinyylin pizzatunnus: ");
		vinyyliId = input.nextInt();
		input.nextLine();

		VinyyliDAO vinyylidao = new VinyyliJdbcDao();
		
		boolean onnistuiPoisto = vinyylidao.removeVinyyli(vinyyliId);
		if (onnistuiPoisto) {
			System.out.println("Vinyylin poisto tietokantasta onnistui.");
		} else {
			System.out.println("Vinyylin poisto tietokantasta ei onnistunut.");
		}
	}	
	
	
}