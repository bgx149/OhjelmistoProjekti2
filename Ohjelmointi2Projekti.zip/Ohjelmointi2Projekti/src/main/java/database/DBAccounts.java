package database;

public class DBAccounts {
	
	
	// SQLite-tietokannan tunnukset
	// DBURL = JDBC_URL
	public static final String DBURL = "jdbc:sqlite:C:\\Users\\alexk\\Documents\\Ohjelmointi 2\\sqlite-tools-win32-x86-3390400\\vinyylit.sqlite";
	 // protokolla, palvelin, tietokanta

	public static final String DBUSERNAME = null;  // sqlite-testitietokannassa ei käytössä tunnuksia
	public static final String DBPASSWORD = null;
	

}