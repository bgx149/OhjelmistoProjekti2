/**
 * 
 */
package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Vinyyli;

/**
 * @author alexk
 *
 */
public class VinyyliJdbcDao implements VinyyliDAO{

	
	public List<Vinyyli> FindAll() {
		Connection connection = null; // tietokantayhteys
		PreparedStatement statement = null; // SQL-lause
		ResultSet resultset = null; // SELECT-lauseen tulostaulu
		List<Vinyyli> vinyylit = new ArrayList<Vinyyli>();
		Vinyyli vinyyli = null; // apuviittausmuuttuja asiakas-oliolle
		try {
		connection= Database.getDBConnection(); // Luodaan yhteys
		// Luodaan komento:haetaan kaikki rivit customer-taulusta
		String sqlSelect = "SELECT id, artisti, nimi, vuosi, hinta FROM VINYYLIT ORDER BY artisti ASC";
		// Valmistellaan komento:
		statement = connection.prepareStatement(sqlSelect);
		// Lähetetään komento:
		resultset = statement.executeQuery();
		 // Käydään tulostaulun rivit läpi
		while (resultset.next()) {
		vinyyli = createVinyyliObjectFromRow(resultset);
		vinyylit.add(vinyyli); //lisätään asiakas listaan
		
		}
		} catch (SQLException e) {
		e.printStackTrace();
		throw new RuntimeException(e);
		} finally {
		 Database.closeDBConnection(resultset, statement,
		connection); }
		return vinyylit; //palautetaan asiakaslista(List)
		}
	
	
	
	
private Vinyyli createVinyyliObjectFromRow(ResultSet resultset) {
		
		
	
		try {
			int id = resultset.getInt("id");
			String nimi = resultset.getString("nimi");
			String artisti = resultset.getString("artisti");
			int vuosi = resultset.getInt("vuosi");
			double hinta = resultset.getDouble("hinta");
			
			return new Vinyyli(id,artisti,nimi,vuosi, hinta);
			
		}  catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e);}

	}


public boolean addVinyyli(Vinyyli vinyyli)  {
	Connection connection = null;
	PreparedStatement stmtInsert = null;
	boolean updateSuccessed = false; 

	try {
		// Luodaan tietokantayhteys
		connection = Database.getDBConnection();
		// Luodaan komento: luodaan uusi asiakas tietokannan tauluun
		String sqlInsert = 
				"INSERT INTO VINYYLIT (artisti, nimi, vuosi, hinta) VALUES (?, ?, ?, ?)";
		// Valmistellaan komento:
		stmtInsert = connection.prepareStatement(sqlInsert);
		// Asetetaan parametrisoidun komennon parametrit yksi kerrallaan 
        // customer-taulussa id-sarakkeen arvo autom. generoituva, joten ei mukana insertissä
		stmtInsert.setString(1, vinyyli.getArtisti());
		stmtInsert.setString(2, vinyyli.getNimi());
		stmtInsert.setInt(3, vinyyli.getVuosi());
		stmtInsert.setDouble(4, vinyyli.getHinta());
	
		//Lähetetään INSERT-komento suoritettavaksi tietokantapalvelimelle
		int rowAffected = stmtInsert.executeUpdate();
		if (rowAffected == 1) updateSuccessed = true;
		
	} catch (SQLException e) {
		e.printStackTrace(); // consoleen näkyviin Exception-tilanteen tarkemmat tiedot vianjäljitystä varten
		throw new RuntimeException(e);
	} finally {
		Database.closeDBConnection(stmtInsert, connection); // Suljetaan statement ja yhteys
	}
	return updateSuccessed;
}


public boolean removeVinyyli(int vinyyliId) {
	Connection connection = null;
	PreparedStatement stmtDelete = null;
	boolean updateSuccessed = false;

	try {
		// Luodaan tietokantayhteys
		connection = Database.getDBConnection();
		//Poistetaan henkilo tietokantasta:
		String sql = "DELETE FROM VINYYLIT WHERE id = ?";
		stmtDelete = connection.prepareStatement(sql);
		// Asetetaan parametrisoidun delete-komennon parametri 
		stmtDelete.setInt(1, vinyyliId);
		//Lähetetään DELETE-komento suoritettavaksi tietokantapalvelimelle
		int rowAffected = stmtDelete.executeUpdate();
		if (rowAffected == 1) updateSuccessed = true;
		
	} catch (SQLException e) {
		e.printStackTrace(); // consoleen näkyviin Exception-tilanteen tarkemmat tiedot vianjäljitystä varten
		throw new RuntimeException(e);
	} finally {
		Database.closeDBConnection(stmtDelete, connection); // Suljetaan statement ja yhteys
	}
	return updateSuccessed;
}

public public List<Vinyyli> EtsiVinyyli(){
	
	Connection connection = null; // tietokantayhteys
	PreparedStatement statement = null; // SQL-lause
	ResultSet resultset = null; // SELECT-lauseen tulostaulu
	List<Vinyyli> vinyylit = new ArrayList<Vinyyli>();
	Vinyyli vinyyli = null; // apuviittausmuuttuja vinyyli-oliolle
	try {
	connection= Database.getDBConnection(); // Luodaan yhteys
	// Luodaan komento:haetaan kaikki rivit customer-taulusta
	String sqlSelect = "SELECT id, artisti, nimi, vuosi, hinta FROM VINYYLIT WHERE artisti = ?, nimi =?, vuosi = ?";
	// Valmistellaan komento:
	statement = connection.prepareStatement(sqlSelect);
	// Lähetetään komento:
	resultset = statement.executeQuery();
	 // Käydään tulostaulun rivit läpi
	while (resultset.next()) {
	vinyyli = createVinyyliObjectFromRow(resultset);
	vinyylit.add(vinyyli); //lisätään vinyyli listaan
	
	}
	} catch (SQLException e) {
	e.printStackTrace();
	throw new RuntimeException(e);
	} finally {
	 Database.closeDBConnection(resultset, statement,
	connection); }
	return vinyylit; //palautetaan vinyyli(List)
	}





}









