package database;

import java.util.List;
import model.Vinyyli;

public interface VinyyliDAO {
	
	
	
	public List<Vinyyli> FindAll();

	public boolean addVinyyli(Vinyyli uusiVinyyli);

	public boolean removeVinyyli(int vinyyliId);
	
	
	

}
