package model;

import java.text.DecimalFormat;

public class Vinyyli  {
	
	
	
	 private int id;
	 private String artisti;
	 private  String nimi;
	 private int vuosi;
	 private  Double hinta;
	 
	 private static final DecimalFormat df = new DecimalFormat("0.00");
	 
	 public Vinyyli(int id, String artisti, String nimi, int vuosi, double hinta) {
		 this.id = id;
		 this.nimi = nimi;
		 this.artisti = artisti;
		 this.vuosi = vuosi;
		 this.hinta = hinta;
		// TODO Auto-generated constructor stub
	}
	 





	@Override
	public String toString() {
		return  id + " " + artisti + " " + nimi + " " + vuosi + " "  + hinta + " €";
	}
	 
	 
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNimi() {
		return nimi;
	}
	public void setNimi(String nimi) {
		this.nimi = nimi;
	}
	public String getArtisti() {
		return artisti;
	}
	public void setArtisti(String artisti) {
		this.artisti = artisti;
	}
	public Double getHinta() {
		return hinta;
	}
	public void setHinta(Double hinta) {
		this.hinta = hinta;
	}
	
	
	
	public int getVuosi() {
		return vuosi;
	}


	public void setVuosi(int vuosi) {
		this.vuosi = vuosi;
	}






	public String getHintaStr() {
		
		String hintaStr = df.format(hinta).toString();
	
		return hintaStr;
		
	}
	
public String getVuosiStr() {
		
		String vuosiStr = String.valueOf(vuosi);
		return vuosiStr;
		
	}






	
	


	
}
