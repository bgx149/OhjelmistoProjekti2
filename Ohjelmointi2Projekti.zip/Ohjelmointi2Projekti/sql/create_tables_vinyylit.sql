CREATE TABLE VINYYLIT(
id integer,
artisti varchar(50) not null,
nimi varchar(50) not null,
vuosi integer (4) not null,
hinta decimal(5,2) not null,
primary key(id));

